import subprocess
import os
import sys

current_dir = os.path.dirname(os.path.abspath(__file__))
server_path = os.path.join(current_dir, "server.js")

node_path = r"C:\Program Files\nodejs\node.exe"

si = subprocess.STARTUPINFO()
si.dwFlags |= subprocess.STARTF_USESHOWWINDOW 
si.wShowWindow = subprocess.SW_HIDE

subprocess.Popen([node_path, server_path], startupinfo=si)
