const RPC = require("discord-rpc");
const axios = require("axios");
require("dotenv").config();
const clientId = process.env.DISCORD_CLIENT_ID;
const CR_TOKEN = process.env.CR_TOKEN;
const PLAYER_TAG_ENCODED = encodeURIComponent(process.env.CR_TAG);
const GOAL = Number(process.env.GOAL_TROPHIES || 8000); 

console.log("DEBUG ENV:", {
  DISCORD_CLIENT_ID: clientId,  
  CR_TOKEN: CR_TOKEN ? "loaded" : "missing",
  CR_TAG: process.env.CR_TAG  
});

if (!clientId || !CR_TOKEN || !PLAYER_TAG_ENCODED) {
  console.error("Missing DISCORD_CLIENT_ID, CR_TOKEN, or CR_TAG in .env");
  process.exit(1);
}

RPC.register(clientId);
const rpc = new RPC.Client({ transport: "ipc" });

const api = axios.create({
  baseURL: "https://api.clashroyale.com/v1",
  headers: {
    Authorization: `Bearer ${CR_TOKEN}`,
    "Cache-Control": "no-cache", 
    Pragma: "no-cache",     
  },
  timeout: 8000,
});

let startTimestamp = Date.now();

async function getPlayer() {
  const { data } = await api.get(`/players/%23${PLAYER_TAG_ENCODED.replace("%23", "")}`);
  return data;
}

const arenas = [
  "Training Camp",       // Arena 1
  "Goblin Stadium",      // Arena 2
  "Bone Pit",            // Arena 3
  "Barbarian Bowl",      // Arena 4
  "Spell Valley",        // Arena 5
  "Builder's Workshop",  // Arena 6
  "P.E.K.K.A's Playhouse",// Arena 7
  "Royal Arena",         // Arena 8
  "Frozen Peak",         // Arena 9
  "Jungle Arena",        // Arena 10
  "Hog Mountain",        // Arena 11
  "Electro Valley",      // Arena 12
  "Spooky Town",         // Arena 13
  "Rascal's Hideout",    // Arena 14
  "Serenity Peak",       // Arena 15
  "Miner's Mine",        // Arena 16
  "Executioner's Kitchen",// Arena 17
  "Royal Crypt",         // Arena 18
  "Silent Sanctuary",    // Arena 19
  "Dragon Spa",          // Arena 20
  "Boot Camp",           // Arena 21
  "Clash Fest",          // Arena 22
  "PANCAKES!",           // Arena 23
  "Legendary Arena",     // Arena 24
  "King's Journey",      // Arena 25 
  "Royal Way (Guardian)",           // Path of Legends Stage 1
  "Imperial Arena (Master I)",      // Path of Legends Stage 2
  "Savage Spire (Master II)",        // Path of Legends Stage 3
  "Forbidden Fortress (Master III)",  // Path of Legends Stage 4
  "Ruler's Road (Champion)",        // Path of Legends Stage 5
  "Champion's Domain (Grand Champion)",   // Path of Legends Stage 6
  "Ultimate Champion (Royal Champion)"    // Path of Legends Stage 7
];


const arenaTrophyThresholds = [
  0,    // Training Camp (Arena 1)
  300,  // Goblin Stadium (Arena 2)
  600,  // Bone Pit (Arena 3)
  1000, // Barbarian Bowl (Arena 4)
  1300, // Spell Valley (Arena 5)
  1600, // Builder's Workshop (Arena 6)
  2000, // P.E.K.K.A's Playhouse (Arena 7)
  2300, // Royal Arena (Arena 8)
  2600, // Frozen Peak (Arena 9)
  3000, // Jungle Arena (Arena 10)
  3300, // Hog Mountain (Arena 11)
  3600, // Electro Valley (Arena 12)
  4000, // Spooky Town (Arena 13)
  4300, // Rascal's Hideout (Arena 14)
  4600, // Serenity Peak (Arena 15)
  5000, // Miner's Mine (Arena 16)
  5300, // Executioner's Kitchen (Arena 17)
  5600, // Royal Crypt (Arena 18)
  6000, // Silent Sanctuary (Arena 19)
  7500, // Dragon Spa (Arena 20)
  8000, // Boot Camp (Arena 21) 
  8500, // Clash Fest (Arena 22) 
  9000, // PANCAKES! (Arena 23)
  9500, // Legendary Arena (Arena 24) 
  10000, // King's Journey (Arena 25)

  10500, // Path of Legends - Guardian
  11000, // Path of Legends - Master I
  11500, // Path of Legends - Master II
  12000, // Path of Legends - Master III
  12500, // Path of Legends - Champion
  13000, // Path of Legends - Grand Champion
  13500  // Path of Legends - Ultimate Champion
];

function formatState({ trophies, arena, expLevel }) {
  const arenaName = arena?.name;
  let arenaNumber = "?";
  let targetTrophies = null; 
  let trophyLine;

  if (arenaName) {
    const currentIndex = arenas.indexOf(arenaName);
    if (currentIndex !== -1) {
      arenaNumber = currentIndex + 1;

      if (trophies < arenaTrophyThresholds[currentIndex]) {
        targetTrophies = arenaTrophyThresholds[currentIndex]; 
      } 
      else if (currentIndex < arenas.length - 1) { 
        targetTrophies = arenaTrophyThresholds[currentIndex + 1]; 
      }
    }
  }

  if (targetTrophies && trophies < targetTrophies) {
    trophyLine = `🏆 Trophies: ${trophies}/${targetTrophies}`;
  } else {

    trophyLine = `🏆 Trophies: ${trophies}`;
  }

  return `${trophyLine} • 🏯 Arena: ${arenaNumber} • ⭐ Level: ${expLevel}`;
}

async function updatePresence() {
  console.log("Attempting to update presence...");
  try {
    const p = await getPlayer();
    
    console.log("Player data received:", { trophies: p.trophies, arena: p.arena?.name, expLevel: p.expLevel });

    rpc.setActivity({
      details: "Clash Royale",
      state: formatState(p),
      startTimestamp,
      largeImageKey: "clash_royale",
      largeImageText: "Clash Royale",
      instance: false,
    });
    console.log("Presence updated successfully.");
  } catch (err) {
    console.error("Update failed:", err?.response?.status || "", err?.message);
  }
}

rpc.on("ready", async () => {
  console.log("RPC Ready!");
  await updatePresence(); 
  setInterval(updatePresence, 15 * 1000); 
});

rpc
  .login({ clientId })
  .catch((e) => console.error("RPC login failed:", e.message));
